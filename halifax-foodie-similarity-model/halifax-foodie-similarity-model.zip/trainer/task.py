import trainer.model as model


def main():
    model.create()


if __name__ == '__main__':
    main()
